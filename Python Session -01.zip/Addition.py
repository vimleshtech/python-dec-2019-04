#WAP to get sum of two numbers
n1 = 444  #n1 is variable (temp. memory where data can be stored), and 444 is data
n2 = 50


#expression
n = n1+n2

print('sum of two numbers ',n)




