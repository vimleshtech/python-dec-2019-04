sal=int(input('Input the salary:'))
if sal>5000 and sal<=10000 :
    hra=sal*10/100
    da=sal*5/100
    tot_sal=sal+hra+da
    print('The total salary is:',tot_sal)
elif sal>10001 and sal<=15000 :
    hra=sal*15/100
    da=sal*8/100
    tot_sal=sal+hra+da
    print('The total salary is:',tot_sal)
 
else:
    print("The salary is out of range")
