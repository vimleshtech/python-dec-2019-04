print('hi',end=' ')
print('raman')

#print in multiple line
print('this is\n test code ')

a =12
b =5
c =a+b

print('sum of a and b is c')
print('sum of ',a,' and ',b,' is ',c)

print('sum of {} and {} is {}'.format(a,b,c))

print('sum of {1} and {0} is {2}'.format(a,b,c))

#print('sum of {0} and {1} is {}'.format(a,b,c)) #error 

