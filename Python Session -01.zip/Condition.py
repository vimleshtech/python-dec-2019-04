sales = int(input('enter sale amt :'))

tax  = 0
if sales>1000:
    tax = sales*.18


total = sales+tax
print('total amt is :',total)
