social=int(input("Inout the marks of social:"))
science=int(input("Inout the marks of science:"))
maths=int(input("Inout the marks of maths:"))
english=int(input("Inout the marks of english:"))
hindi=int(input("Inout the marks of hindi:"))
avg=(social+science+maths+english+hindi)/5
if avg<40 :
    print("Your have faied in ur exams with avg of:",avg)
elif avg>40 and avg<=49:
    print("You have scored Third division",avg)
elif avg>50 and avg<=59:
    print("You have secured Second Division",avg)
elif avg>=60:
    print("U have secured First Division, Congrats",avg)

else:
    print("You have problems relaed to ur exams")
