a =55
b =555

c =a+b
print(c)

