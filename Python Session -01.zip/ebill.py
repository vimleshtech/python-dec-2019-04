ebill=int(input("INput ur number of Units of Electricity"))
ibill=50


if ebill>0 and ebill<=100 :
    tbill=ebill*0.4+ibill
    print("The total bill for",ebill,"is",tbill,"Rs")

elif ebill>100 and ebill<=200 :
    f_bill=100*0.4+ibill
    s_bill=(ebill-100)*0.5
    g_bill=f_bill+s_bill
    print("The total bill for",ebill,"is",g_bill,"Rs")

elif ebill>200 and ebill<=300 :
    
    f_bill=140+(ebill-300)*0.6
    g_bill=f_bill+ibill
    print("The total bill for",ebill,"is",g_bill,"Rs") 

else:
    print("Pls input only numbers")
        
