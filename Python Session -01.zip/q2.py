rn = int(input('enter roll number :'))
name = input('enter name :')

hs = int(input('enter mark in hindi '))
es = int(input('enter mark in eng '))
cs = int(input('enter mark in comp '))
ss = int(input('enter mark in social '))
his = int(input('enter mark in hist. '))


total  = hs+es+cs+ss+his
avg = total/5

print('roll number ',rn)
print('name is ',name)
print('total score is ',total)
print('average score is ',avg)

         
