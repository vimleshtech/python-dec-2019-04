sales = int(input('enter sale amt :'))

tax  = 0
if sales>10000:
    tax = sales*.18
elif sales>1000:
    tax = sales*.12
elif sales>5000:
    tax = sales*.10
elif sales>2000:
    tax = sales*.05
else:
    tax = sales*.02
        

total = sales+tax
print('total amt is :',total)
