#c = 0

def add(a,b):
    global c
    c =a+b #c is local variable
    print(c)




add(11,4)
print(c)

      
