import math
import random

o = math.factorial(100)
print(o)


o = math.sqrt(100)
print(o)



o = math.pow(100,3)
print(o)


print(random.randint(1000,9999))

