days = {'mon':1,'tue':2,'wed':3,'thu':4,'fri':5,'sat':6,'sun':7}


print(type(days))
print(days)
print(days.keys())
print(days.values())

#add
days['other'] =100
print(days)

#update
days['mon'] =11
print(days)

#
print(days.items())

#
for k,v in days.items():
    #print(v)
    if v==4:
        print(k)
    

print(days['fri'])


x = list(days.keys())
y = list(days.values())
print(x)
print(y)


