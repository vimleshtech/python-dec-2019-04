#break : stop the loop when condition wil match 
for i in range(1,10):
    if i%3 ==0: #if number will divide by 3 then stop the loop
        break     
    print(i)
    

#continue : skip the current iteration and resume from next
for i in range(1,10):
    if i%3 ==0: 
        continue
    print(i)

#1 2 4 5 7 8
    
    
