for x in range(10):
    print(x)
    
for x in range(2,10):
    print(x)
    

for x in range(2,10,2):
    print(x)

#print in reverse
print('....')
for i in range(10,0,-1):
    print(i)
    
