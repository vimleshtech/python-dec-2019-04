
sales = [111,32,44,5566,33,5666]

print('max value is ',max(sales))
print('min value is ',min(sales))
print('sum value is ',sum(sales))
print('count is ',len(sales))



sales.sort()
print(sales)

#slicer
print(sales[0]) #return first value 
print(sales[1]) #return 2nd value
print(sales[-1]) #return last value

print(sales[0:4]) #from 0 to 3
print(sales[:4]) #from 0 to 3
print(sales[1:4]) #from 1 to 3

print(sales) #print all
print(sales[::]) #print all

#print in reverse
print(sales[::-1])
print(sales[::-2])


sales.append(100)
sales.append(10)
print(sales)


sales.pop()
print(sales)

sales.insert(1,20)
print(sales)

sales.remove(20) #remove all need value; not index 
print(sales)

sales.remove(sales[2])






      
