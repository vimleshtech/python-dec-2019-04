sales = [] #empty list

for x in range(4):
    amt = int(input('enter data :'))
    sales.append(amt)


print(sales)

#print one by one
for m in sales:
    print(m)

#or
for i in range(len(sales)):
    print(sales[i])
    

