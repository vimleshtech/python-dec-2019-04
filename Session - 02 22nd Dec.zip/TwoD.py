#two d

users=[[1,'nitin','male'],[2,'rahul','male']]

print(users)
print(users[0]) #first row
print(users[0][1]) #first row and name 

for r in users:
    print(r)
    
#data by data
for r in users: #table to row
    for c in r:  #row to col
        print(c,end='\t')
    print()
