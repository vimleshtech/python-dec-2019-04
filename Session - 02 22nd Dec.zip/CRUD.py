#CRUD : Create, read, update, delete

data= []
while True:
    ch = input('press 1 to add, 2 to show , 3 for delete, 4 for update, 0 for exit')

    if ch=='1':
        d = int(input('enter data :'))
        data.append(d)
        
        
    elif ch=='2':
        print(data)
        

    elif ch=='3':
        a = int(input('enter data to remove '))
        if a in data:
            data.remove(a)
            print('given value is removed')
        else:
            print('given is not foundt')
        

    elif ch=='4':
        a = int(input('enter data to remove '))

        if a not in data:
            print('given value is not found ')
        else:
            
            for i in range(len(data)):
                if data[i] == a:
                    nv = int(input('enter new value '))
                    data[i] =nv
                
        

    elif ch=='0':
        break #exit 
        
    else:
        print('invaid choice, plz try again !!!')
        

    
