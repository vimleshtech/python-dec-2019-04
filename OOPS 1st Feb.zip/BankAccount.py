class BankAccount:

    def __init__(self):
        self.name=''
        self.acno =0
        self.pan =''
        self.balance=0

    def input(self,name,acno,pan,balance):
        self.name = name
        self.acno = acno
        self.pan = pan
        self.balance = balance
        
    def diposit(self,amt):
        self.balance+=amt
    def withdrawn(self,amt):
        if self.balance<1 or self.balance<amt:
            print('insufficient balance  ..')
        else:
            self.balance -= amt

    def show(self):
        print(self.acno)
        print(self.name)
        print(self.balance)
        


            

    
