global a
a =1
print(a)

class Tax:

    def GST(self,amt):
        tax = 0
        if amt>100000:
            tax = amt*.18
        elif amt>10000:
            tax = amt*.12
        else:
            tax = amt*.05
        print(tax)
        
    def __init__(self):
        print('object is created ',self)
        self.bank_amt  = 5000
        self.player_init  = 1000

    def game(self):
        if self.bank_amt<1:
            print('bank is crupted you can not play the game ')
        else:
            if 1==1:
                self.bank_amt-= 200
            else:
                self.bank_amt+= 150
            
            
        
    def __del__(self):
        print('object is reoved ',self)
        

#create object
o = Tax()
o.GST(34566)
del o # o is removed 

#o.GST(34566) #error 






            
        
