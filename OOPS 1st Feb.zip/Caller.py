from SA import SavingAccount

#multi level 
class hello(SavingAccount):
    def test(self):
             print('hello ')
    

o = hello()
o.int()
o.rd()
o.input('Nitin',10002334,'BGRPK01JFJJ',34000)

o.show()
o.test()


                                                 
