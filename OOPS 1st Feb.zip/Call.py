class cal:
    
    def add(self,a,b=0,c=0,d=0):
        print(a+b+c+d)

    def add(self, a, b,c,d,e,f):
        print(a+b+c+d+e+f)
        

o=cal()
o.add(11,4411,33,4,5566,55)
o.add(55,66,446,55,767,88)

		
