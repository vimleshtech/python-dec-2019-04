from BankAccount import BankAccount as bank
#import BankAccount.BankAccount as bank

class SavingAccount(bank):


    def int(self):
        print('4% on saving  ')


    def rd(self):
        print('6% on rd')
    
              
        
    
    
    
