f = open(r'C:\Users\vkumar15\Desktop\out.txt','r')

#get row count
d = f.readlines()
print('row count ',len(d))

#word count
wc = 0
for r in d:
    c  = r.split(",")
    wc =wc+len(c)
    c  = r.split(" ")
    wc =wc+len(c)
    


f.close()

print('wrod count ',wc)

    
