####wap to create a file from code and write data


f = open(r'C:\Users\vkumar15\Desktop\out.txt','a') #w - overwirte, a  - append


#f.write('hi\n')
#f.write('test code\n')

for i in range(5):
    d= input('enter data :')
    f.write(d+"\n")
    
    
f.close()

print('file is saved')



