f = open(r'C:\Users\vkumar15\Desktop\emp.txt','r')

#get row count
d = f.readlines()

mc = 0
fc = 0
ms = 0
fs = 0
for r in d:
    #print(r)
    c = r.split(",")
    print(c)
    if c[2]=='male':
        mc =mc+1
        ms = ms+int(c[3])
    elif c[2]=='female':
        fc=fc+1
        fs = fs+int(c[3])



print('male count ',mc)
print('female count ',fc)
print('male total sal ',ms)
print('female total sal ',fs)

    



        
    
