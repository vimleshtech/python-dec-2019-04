
data= open(r'C:\Users\vkumar15\Desktop\Python Session -01.txt') #erro 

#print(data.read()) #read all data from file

#print(data.readline())#read first line
#print(data.readline())#read first line
#print(data.readline())#read first line

d = data.readlines()
#print(d)

'''


for r in  d:
    print(r)

'''
#print 4th row
print(d[2])


