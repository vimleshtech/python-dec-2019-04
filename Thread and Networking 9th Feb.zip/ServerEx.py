import socket               # Import socket module
import random

s = socket.socket()         # Create a socket object
host = socket.gethostname() # Get local machine name

port = 4000               # Reserve a port for your service.
s.bind((host, port))        # Bind to the port


s.listen(50)                 # Now wait for client connection.
while True:
   c, adr = s.accept()     # Establish connection with client.
   
   print('we have recieved the request ')
   otp = str(random.randint(1000,9999))
       
   c.send(otp.encode())
   
   c.close()                # Close the connection
   

