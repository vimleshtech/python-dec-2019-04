import time
import threading

def process1():
    i =1
    while True:
        print('in process-1 ',i)
        time.sleep(5)
        i = i+1

def process2():
    i =11
    while True:
        print('in process-2 ',i)
        time.sleep(5)
        i =i+1



#process1()
#process2()

#convert function , assign function to process 
t1 = threading.Thread(target=process1,name='p1')
t2 = threading.Thread(target=process2,name='p2')

t1.start()
t2.start()







    
    
