class employee:

    #we have to receive at least one argument in every function which declare within class
    def newemp(self): 
        print('in new emp ',self)
        self.eid  = input('enter eid :')
        self.name  = input('enter name :')
        self.basic =int( input('enter basic sal :'))
        
    def compute(self):
        print('in compute ')
        self.hra = self.basic*.40
        self.da = self.basic*.40
        self.total = self.basic+self.hra+self.da
        
    def attend(self):
        print('in attend ')
        
    def show(s):
        print('in show')
        print('eid is ',s.eid)
        print('name is ',s.name)
        print('basic sal ',s.basic)
        print('total sal ',s.total)
        
        
        
e1 = employee()
e2 = employee()
e3 = employee()
print(e1)
#print(e2)
#print(e3)
e1.newemp()
e2.newemp()
e3.newemp()

e1.compute()
e2.compute()
e3.compute()

e2.show()
e1.show()
e3.show()










        
    
