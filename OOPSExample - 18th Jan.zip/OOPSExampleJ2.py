class employee:
    #we have to receive at least one argument in every function which declare within class
    def newemp(self): 
        print('in new emp ',self)
        self.eid  = input('enter eid :')
        self.name  = input('enter name :')
        self.basic =int( input('enter basic sal :'))
        
    def compute(self):
        print('in compute ')
        self.hra = self.basic*.40
        self.da = self.basic*.40
        self.total = self.basic+self.hra+self.da

    def show(s):
        print('in show')
        print('eid is ',s.eid)
        print('name is ',s.name)
        print('basic sal ',s.basic)
        print('total sal ',s.total)
        
emps = []
for i in range(200):
    e = employee()
    e.newemp()
    e.compute()
    emps.append(e)

for x in emps:
    x.show()
    

    
    
    
